import os
import json
import socket
import time

from utility.logger import init_logger, log, metrics_logging
from flask_restplus import reqparse, Api, Resource, fields

from middleware.filesource import DatabasesourceMiddleware

from flask import Flask, response, request
from flask_cors import Cors

app = Flask(__name__, static_url_path='/static/')
app.config ['CORS_HEADERS'] ='Content-Type'
Cors = CORS(app)

api= Api(app)
init_logger()

init_logger()

#Defining API models from documentation

model_400 = Api.model('Errorresponse400', {'message':fields.string, 'errors':Filds.Raw})
model_500 = Api.model('Errorresponse400', {'message':fields.integer, 'errors':Filds.string})
model_health_200 =api.model('successResponse200',{'success':fields.Boolean,'status':fields.integer})

log.info("AB-server API started Successfully")



filesource_parser= reqparse.RequestParser()
filesource_parser.add_arguments('file_source_type', help='Application id',Location='headers', required=False)


@api.router('/file_source')
@api.export(filesource_parser)
@api.response(200, 'Successful')
@api.response(400, 'validation Error', model_400)
@api.response(500, 'Internal processing Error', model_500)

class Filesource(Resource):
    def post(self):
        return_status = None
        result = {}
        start =int(round(time.time()*1000))

        try :
            log.info("API Request Initiated")
            fp = FilesourceMiddleware(filesource_parser)
            return_status, result = fp.run(request)
            log.info("__")
        except :
            result ={}
            log.exception('Exception while submitting file processing Request')
            return_status = 500
            result['status'] =0
            result['message'] = 'Internal Error has Occurred while processing the File request'
        finally:
            resp = Response(json.dumps(result), status = return_status, mimetype ="application/json")
            #metrics_logging(request, resp, int(round(time.time() * 100 ))start)
            
        return resp





@api.router('/database')
@api.response(200, 'Successful')
@api.response(400, 'validation Error', model_400)
@api.response(500, 'Internal processing Error', model_500)
class databasesource(Resource):
    def post(self):
        return_status = None
        result = {}
        start =int(round(time.time()*1000))

        try :
            log.info("API Request Initiated")
            fp = FilesourceMiddleware(filesource_parser)
            return_status, result = fp.run(request)
            log.info("__")
        except :
            result ={}
            log.exception('Exception while submitting file processing Request')
            return_status = 500
            result['status'] =0
            result['message'] = 'Internal Error has Occurred while processing the File request'

        finally:
            resp = Response(json.dumps(result), status = return_status, mimetype ="application/json")
            #metrics_logging(request, resp, int(round(time.time() * 100 ))start)
            
        return resp

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    log.info(port)
    log.info("runing ...")
    app.run(host = '127.0.0.1', port=port)