import pandas as pd
import os
from .filevalidate import Filevalidate

from utility.logger import log

class Fileprocess (Filevalidate):

    def _init_ (self,file_details):
        self.file_details=file_details
    
    def get_file_type (self, filename) :
        return os.path.splitext (filename) [1] [1:]
    
    def validate(self):
        err_msg=None
        if not self.file_exists_check(self.file_details['file']):
            err msg="File is not exists in this path,please give correct file path details"
        elif not self.non_empty file _check(self.file_details['file']):
            err msg="File is empty,please give correct non empty file"
        elif not self.file_extension_check(self.file details['file']):
            err _msg="Sunpported file extensions excel,csv,txt only"
        
        if not err_msg:
            err _ msg="successful"

        return err_msg

    def excel_file proces (self):
        if self.file details["sheet_id"]=="no":
        output=pd.ExcelPile(self.file_details['file']) .sheet_names
        elif self.file details["sreet_ind")=="yes":
            output=pd.read_excel(self.file_details['file'],sheet_name=self.file_ details['sheet_name']).to_dict (orient="records")
        return output

    def non_excel_file process (self):
        if self.file_ details["delimiter_ind"]=="no":
            with open(self.file_details['file']) as f:
                output=f.readlines ()
        else:
            if self.get_file_type(self.file_details['file']) in ("csv","txt") and self.file details['fwf_type']=="no":
                output=pd.read_csv(self.file_details['file'],sep=self.file_details['delimiter']).to_dict(orient="records")
            elif self.get_file_type(self.file_detailsf['file']) == “txt" and self.file_details['fwf_type']=="yes":
                output= pd.read_fwf (self.file_details['file'],colspecs=self.file_ details['colspecs']).to_dict (orient="rescords")
            else:
                output="invalid file,please check the file content"
            return output