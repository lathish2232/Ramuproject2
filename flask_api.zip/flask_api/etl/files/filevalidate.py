import os
import pandas as pd

class Filevalidate():
    def file _exists_check (self, filename):
        return os.path.isfile (filename)

    def non_emicty file check (self,filename):
        return os.path.getsize (filename) > 0

    def file_expension_check (self, filename):
        file_extention=os.path.splitext (filename) [1] [1:]
        return file extention in ("xlsx","csv","txt")