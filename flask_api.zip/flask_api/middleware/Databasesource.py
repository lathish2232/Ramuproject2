import requests
import json
import os
from datetime import datetime
from utility.logger import log
import pandas as pd


from etl.files.fileprocess import Fileprocess

class DatabasesourceMiddleware:
    def __init__ (self):
        pass

    def run(self, request):
        """
        This functiin stare the user feedback received from Ul server
        """
        return_status = None
        result = {}
        #log.info(f"aras: (str(seli.args)}")
        try:
            # validate payload
            log.info(request.args)
            log.info(request.json)
            
            
            etl_obj=Databaseprocess (request .json)

            data = etl_obj.process_db_details()

            return_status = 200
            result['status'] = 1
            result ['data’ )=data

        except ValueError as e:
            result = {}
            log.exception("Value Excerticon while submitting feedback")
            result['status') = 0
            return_status = 400
            result ['message'] = e.args[0]
        except:
            result = {}
            log.exception("Exception while submitting feedback")
            return_status = 500
            result['status') = 0
            result ['message']  = ("Internal Error has occurred while processing the request")

        return return_status ,result