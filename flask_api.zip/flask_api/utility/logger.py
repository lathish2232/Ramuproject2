import yaml
import os
import logging
import logging.config
import json
import sys
import socket
from datetime import datetime


def init_logger():
    with open(os.path.join(os.path.dirname(os.path.dirname(__file__ )), 'conf\legger.yaml'), 'rt') as f:
        config = yaml.safe_load(f.read())

        # replacing the default log level from yaml file with a env value if one is set
        if os.environ.get('LOG LEVEL') is not None:
            config.get('root') ['level'] = os.environ.get ('LOG LEVEL')
    logging.config.dictConfig (config)


'''
def metrics_logging (request, resp, tookmsec):
    metric = {}
    log.info(f"function invoked: metricsLoggirng, with parameters: response[{str(reso)}], tookmsec[{str(tcackmsec)}]")
    try:
        metric['autnorization'] = request. headers.get ("authorization")
        metric['logtracking id'] = request .headers.get ("logtrackingId")
        metric['apP_id'] = request.headers.get ("arpid")
        metric['uri'] = request.path.encode ('utf-8')
       
        if request.method != "GET":
            metric['req body'] = json.dumps (request.json)
        else:
            metric['reg sody'] = json.dumps('')
            metric['resp body'] = resp.data
            metric['yuery params'] = json.dumps (request.args)
'''

log =logging.getLogger('app')